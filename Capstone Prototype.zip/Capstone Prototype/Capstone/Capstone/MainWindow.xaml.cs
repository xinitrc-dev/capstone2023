﻿using NAudio.CoreAudioApi;
using NAudio.Wave;
using System;
using System.Runtime.Intrinsics.X86;
using System.Threading;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media;

namespace Capstone
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        MMDeviceEnumerator enumerator;
        MMDevice device;
        int multiplier = 100;
        const int DISPLAY_SIZE_MULTIPLIER = 300;

        WasapiCapture AudioDevice;
        double[] FftValues;
        double[] AudioValues;

        

        public MainWindow()
        {
            InitializeComponent();
        }

        public void Loop()
        {
            enumerator = new MMDeviceEnumerator();
            device = enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Console);
            //select audio device
            WasapiCapture audioDevice = device.DataFlow == DataFlow.Render
                    ? new WasapiLoopbackCapture(device)
                    : new WasapiCapture(device, true, 10);

            AudioDevice = audioDevice;

            WaveFormat fmt = AudioDevice.WaveFormat;
            AudioValues = new double[fmt.SampleRate / 10];
            double[] paddedAudio = FftSharp.Pad.ZeroPad(AudioValues);
            double[] fftMag = FftSharp.Transform.FFTpower(paddedAudio);
            FftValues = new double[fftMag.Length];
            double fftPeriod = FftSharp.Transform.FFTfreqPeriod(fmt.SampleRate, fftMag.Length);

            AudioDevice.DataAvailable += WaveIn_DataAvailable;
            AudioDevice.StartRecording();


            while (true)
            {

                float lefttop = device.AudioMeterInformation.PeakValues[0];
                float righttop = device.AudioMeterInformation.PeakValues[1];

                var tempone = lefttop * multiplier;
                var temptwo = righttop * multiplier;

                var x = 75 - tempone + temptwo;
                var y = 75 - tempone - temptwo;
                if (y < 10)
                {
                    y = 10;
                }
                if (x < 10)
                {
                    x = 10;
                }

                if (y > 140)
                {
                    y = 140;
                }
                if (x > 140)
                {
                    x = 140;
                }
                string infotext = "";
                for (int i = 0; i < device.AudioMeterInformation.PeakValues.Count; i++)
                {
                    infotext += i + " -> " + device.AudioMeterInformation.PeakValues[i] + "\n";
                }
                infotext += $"Frequency -> {GetPeakFrequency(),-6:N0} Hz\n";
                infotext += $"Volume -> {(device.AudioMeterInformation.MasterPeakValue * 100).ToString("0.##")}";
                string hertz = $"{GetPeakFrequency(),-6:N0}";
                double freq = double.Parse(hertz);

                Dispatcher.Invoke((MethodInvoker)delegate
                {
                    label.Content = infotext;
                  
                    if ((device.AudioMeterInformation.PeakValues[0] == 0) && (device.AudioMeterInformation.PeakValues[1] == 0))
                    {
                        w0.Fill = Brushes.White;
                        w1.Fill = Brushes.White;
                        w2.Fill = Brushes.White;
                        w3.Fill = Brushes.White;
                        w4.Fill = Brushes.White;
                        w5.Fill = Brushes.White;
                        w6.Fill = Brushes.White;
                        w7.Fill = Brushes.White;

                        w0.Width = 0;
                        w1.Width = 0;
                        w2.Width = 0;
                        w3.Width = 0;
                        w4.Width = 0;
                        w5.Width = 0;
                        w6.Width = 0;
                        w7.Width = 0;

                        w0.Height = 0;
                        w1.Height = 0;
                        w2.Height = 0;
                        w3.Height = 0;
                        w4.Height = 0;
                        w5.Height = 0;
                        w6.Height = 0;
                        w7.Height = 0;
                    }
                    else
                    {
                        if ((x >= 0) && (x <= 18.75))
                        {
                            if(freq > 1000)
                            {
                                w0.Fill = Brushes.Red;
                            }else if (freq < 300)
                            {
                                w0.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w0.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 18.75) && (x <= 37.5))
                        {
                            if (freq > 1000)
                            {
                                w1.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w1.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w1.Fill = Brushes.Purple;
                            }
                            w0.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 37.5) && (x <= 56.25))
                        {
                            if (freq > 1000)
                            {
                                w2.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w2.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w2.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w0.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 56.25) && (x < 75) && (y != 10))
                        {
                            if (freq > 1000)
                            {
                                w3.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w3.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w3.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w0.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 75) && (x <= 93.75) && (y != 10))
                        {
                            if (freq > 1000)
                            {
                                w4.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w4.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w4.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w0.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 93.75) && (x <= 112.5))
                        {
                            if (freq > 1000)
                            {
                                w5.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w5.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w5.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w0.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w6.Width = 0;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w6.Height = 0;
                            w7.Height = 0;
                        }

                        if ((x > 112.5) && (x <= 131.25))
                        {
                            if (freq > 1000)
                            {
                                w6.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w6.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w6.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w0.Fill = Brushes.White;
                            w7.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w7.Width = 0;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w7.Height = 0;
                        }

                        if ((x > 131.25) && (x < 150))
                        {
                            if (freq > 1000)
                            {
                                w7.Fill = Brushes.Red;
                            }
                            else if (freq < 300)
                            {
                                w7.Fill = Brushes.Blue;
                            }
                            else
                            {
                                w7.Fill = Brushes.Purple;
                            }
                            w1.Fill = Brushes.White;
                            w2.Fill = Brushes.White;
                            w3.Fill = Brushes.White;
                            w4.Fill = Brushes.White;
                            w5.Fill = Brushes.White;
                            w6.Fill = Brushes.White;
                            w0.Fill = Brushes.White;

                            w0.Width = 0;
                            w1.Width = 0;
                            w2.Width = 0;
                            w3.Width = 0;
                            w4.Width = 0;
                            w5.Width = 0;
                            w6.Width = 0;
                            w7.Width = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                            w0.Height = 0;
                            w1.Height = 0;
                            w2.Height = 0;
                            w3.Height = 0;
                            w4.Height = 0;
                            w5.Height = 0;
                            w6.Height = 0;
                            w7.Height = device.AudioMeterInformation.MasterPeakValue * DISPLAY_SIZE_MULTIPLIER;
                        }
                    }
                   
                });
                Thread.Sleep(10);
            }
        }

        private void OnLoad(object sender, RoutedEventArgs e)
        {
            this.Topmost = true;
            Thread t = new Thread(Loop);
            t.Start();
        }

        void WaveIn_DataAvailable(object? sender, WaveInEventArgs e)
        {
            int bytesPerSamplePerChannel = AudioDevice.WaveFormat.BitsPerSample / 8;
            int bytesPerSample = bytesPerSamplePerChannel * AudioDevice.WaveFormat.Channels;
            int bufferSampleCount = e.Buffer.Length / bytesPerSample;

            if (bufferSampleCount >= AudioValues.Length)
            {
                bufferSampleCount = AudioValues.Length;
            }

            if (bytesPerSamplePerChannel == 2 && AudioDevice.WaveFormat.Encoding == WaveFormatEncoding.Pcm)
            {
                for (int i = 0; i < bufferSampleCount; i++)
                    AudioValues[i] = BitConverter.ToInt16(e.Buffer, i * bytesPerSample);
            }
            else if (bytesPerSamplePerChannel == 4 && AudioDevice.WaveFormat.Encoding == WaveFormatEncoding.Pcm)
            {
                for (int i = 0; i < bufferSampleCount; i++)
                    AudioValues[i] = BitConverter.ToInt32(e.Buffer, i * bytesPerSample);
            }
            else if (bytesPerSamplePerChannel == 4 && AudioDevice.WaveFormat.Encoding == WaveFormatEncoding.IeeeFloat)
            {
                for (int i = 0; i < bufferSampleCount; i++)
                    AudioValues[i] = BitConverter.ToSingle(e.Buffer, i * bytesPerSample);
            }
            else
            {
                throw new NotSupportedException(AudioDevice.WaveFormat.ToString());
            }

            //DisplayBandedData(GetPeakFrequency());
        }


        double GetPeakFrequency()
        {
            double[] paddedAudio = FftSharp.Pad.ZeroPad(AudioValues);
            double[] fftMag = FftSharp.Transform.FFTmagnitude(paddedAudio);
            System.Array.Copy(fftMag, FftValues, fftMag.Length);

            // find the frequency peak
            int peakIndex = 0;
            for (int i = 0; i < fftMag.Length; i++)
            {
                if (fftMag[i] > fftMag[peakIndex])
                    peakIndex = i;
            }
            double fftPeriod = FftSharp.Transform.FFTfreqPeriod(AudioDevice.WaveFormat.SampleRate, fftMag.Length);
            double peakFrequency = fftPeriod * peakIndex;

            return peakFrequency;
        }
    }
}